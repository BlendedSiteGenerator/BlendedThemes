jQuery(function($){
    console.log('jQuery loaded ', $)
}(jQuery))
